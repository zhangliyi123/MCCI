import torch
import torch.nn as nn
import torch.nn.functional as F
import ipdb
from torch.distributions import Beta
from torch.autograd import Variable
class Flatten(nn.Module):
    def __init__(self):
        super(Flatten, self).__init__()
    def forward(self, x):
        return x.view(x.size(0), -1)

class FCNet(nn.Module):
    def __init__(self, args, x_dim, hid_dim):
        super(FCNet, self).__init__()
        self.args = args
        self.net = nn.Sequential(
            self.fc_block(x_dim, hid_dim),
            self.fc_block(hid_dim, hid_dim),
        )
        self.dist = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
        self.hid_dim = hid_dim

    def fc_block(self, in_features, out_features):
        return nn.Sequential(
            nn.Linear(in_features, out_features),
            nn.BatchNorm1d(out_features),
            nn.LeakyReLU(),
        )

    def mixup_data(self, xs1, ys1, xs2, ys2, xq1, yq1, xq2, yq2, xq3, yq3, xq4, yq4, xq5, yq5, xs3,  ys3, xs4, ys4, xs5,  ys5,
                   lam1, lam2, lam3,lam4, lam5, lam6, lam7, lam8, lam9):
        query_size = xq3.shape[0]
        shuffled_index1 = torch.randperm(xs1.shape[0])
        shuffled_index2 = torch.randperm(xs2.shape[0])
        shuffled_index3 = torch.randperm(xs3.shape[0])
        shuffled_index4 = torch.randperm(xs4.shape[0])
        shuffled_index5 = torch.randperm(xs5.shape[0])
        shuffled_xq1 = torch.randperm(xq1.shape[0])
        shuffled_xq2 = torch.randperm(xq2.shape[0])
        shuffled_xq3 = torch.randperm(xq3.shape[0])
        shuffled_xq4 = torch.randperm(xq4.shape[0])
        shuffled_xq5 = torch.randperm(xq5.shape[0])
        xs1 = xs1[shuffled_index1]
        xs2 = xs2[shuffled_index2]
        xs3 = xs3[shuffled_index3]
        xs4 = xs4[shuffled_index4]
        xs5 = xs5[shuffled_index5]
        xq1 = xq1[shuffled_xq1]
        xq2 = xq2[shuffled_xq2]
        xq3 = xq3[shuffled_xq3]
        xq4 = xq4[shuffled_xq4]
        xq5 = xq5[shuffled_xq5]
        ys1 = ys1[shuffled_index1]
        ys2 = ys2[shuffled_index2]
        ys3 = ys3[shuffled_index3]
        ys4 = ys4[shuffled_index4]
        ys5 = ys5[shuffled_index5]
        yq1 = yq1[shuffled_xq1]
        yq2 = yq2[shuffled_xq2]
        yq3 = yq3[shuffled_xq3]
        yq4 = yq4[shuffled_xq4]
        yq5 = yq5[shuffled_xq5]
        lam1 = np.clip(lam1, 0, 1)
        lam2 = np.clip(lam2, 0, 1)
        lam3 = np.clip(lam3, 0, 1)
        lam4 = np.clip(lam4, 0, 1)
        lam5 = np.clip(lam5, 0, 1)
        lam6 = np.clip(lam6, 0, 1)
        lam7 = np.clip(lam7, 0, 1)
        lam8 = np.clip(lam8, 0, 1)
        lam9 = np.clip(lam9, 0, 1)
        lam_sum = lam1 + lam2 + lam3 + lam4 + lam5 + lam6 + lam7 + lam8 + lam9 \
                  + (1 - lam1 - lam2 - lam3 - lam4 - lam5 - lam6 - lam7 - lam8 - lam9)  # 0.0 表示 xq 的权重
        lam1 /= lam_sum
        lam2 /= lam_sum
        lam3 /= lam_sum
        lam4 /= lam_sum
        lam5 /= lam_sum
        lam6 /= lam_sum
        lam7 /= lam_sum
        lam8 /= lam_sum
        lam9 /= lam_sum
        mixed_x = lam1 * xs1 + lam2 * xs2 + lam3 * xq1 + lam4 * xs3 + lam5 * xq2 + lam6 * xq3 + lam7 * xs4 +\
        + lam8 * xq4 + max(1 - lam1 - lam2 - lam3 - lam4 - lam5 - lam6 - lam7 - lam8 - lam9 ) * xs5
        return mixed_x, ys1, ys2, ys3, yq1, yq2, ys3, ys4, yq4, lam1, lam2, lam3, lam4, lam5, lam6, lam7, lam8, lam9
    def forward(self, x):
        return self.net(x)

    def forward_within(self, label_support1, inp_support1, inp_support2, label_support2, inp_support3, label_support3,
      inp_support4, label_support4, inp_query4, label_query4, inp_query3, label_query3, inp_query2, label_query2,
                       inp_query1, label_query1, inp_support5, label_support5,
                       lam_mix, lam_mix2, lam_mix3, lam_mix4, lam_mix5, lam_mix6, lam_mix7, lam_mix8):
        hidden1_support = self.net[0](inp_support1)
        hidden1_query = self.net[0](inp_query1)
        hidden2_support = self.net[0](inp_support2)
        hidden3_support = self.net[0](inp_support3)
        hidden4_support = self.net[0](inp_support4)
        hidden5_support = self.net[0](inp_support5)
        hidden2_query = self.net[0](inp_query2)
        hidden3_query = self.net[0](inp_query3)
        hidden4_query = self.net[0](inp_query4)
        hidden1_query, reweighted_query1, reweighted_support1, reweighted_support2, reweighted_support3, reweighted_support4, reweighted_support5,\
        reweighted_query2, reweighted_query3, reweighted_query4,\
        lam1, lam2, lam3, lam4, lam5, lam6, lam7, lam8 = self.mixup_data(hidden1_support, label_support1, hidden1_query, label_query1,
        hidden2_support,  label_support2, hidden3_support,  label_support3, hidden4_support,  label_support4, hidden5_support,  label_support5,
            hidden2_query, label_query2, hidden3_query, label_query3, hidden4_query, label_query4,
            lam_mix, lam_mix2, lam_mix3, lam_mix4, lam_mix5, lam_mix6, lam_mix7, lam_mix8

                                    )
        hidden2_query = self.net[1](hidden1_query)
        return hidden2_query, reweighted_query1, reweighted_support1, reweighted_support2, \
        reweighted_support3, reweighted_support4, reweighted_support5, reweighted_query2,reweighted_query3,
    def forward_crossmix(self, x):
        return self.net[1](x)