import torch
import torch.nn as nn
from torch.distributions import Beta
import numpy as np
# A simple module to flatten the input tensor, typically used to transition between convolutional and fully connected layers.
class Flatten(nn.Module):
    def __init__(self):
        super(Flatten, self).__init__()
    def forward(self, x):
        return x.view(x.size(0), -1)

# Defines a fully connected network with customizable dimensions and two hidden layers.
class FCNet(nn.Module):
    def __init__(self, args, x_dim, hid_dim):
        super(FCNet, self).__init__()
        self.args = args
        self.net = nn.Sequential(
            self.fc_block(x_dim, hid_dim),
            self.fc_block(hid_dim, hid_dim),
        )
        self.dist = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
        self.hid_dim = hid_dim

    # Defines a block for the fully connected layer, including batch normalization and LeakyReLU activation.
    def fc_block(self, in_features, out_features):
        return nn.Sequential(
            nn.Linear(in_features, out_features),
            nn.BatchNorm1d(out_features),
            nn.LeakyReLU(),
        )

    # Applies mixup to the sets of inputs and queries, mixing them according to lam1 and lam2 coefficients.
    def mixup_data(self, xs1, ys1, xs2, ys2, xq, yq, lam1, lam2):
        query_size = xq.shape[0]
        shuffled_index1 = torch.randperm(xs1.shape[0])
        shuffled_index2 = torch.randperm(xs2.shape[0])
        shuffled_xq = torch.randperm(xq.shape[0])
        xs1 = xs1[shuffled_index1]
        xs2 = xs2[shuffled_index2]
        xq = xq[shuffled_xq]
        ys1 = ys1[shuffled_index1]
        ys2 = ys2[shuffled_index2]
        # Ensures lam1 and lam2 values are clipped between 0 and 1 to be valid mixing coefficients.
        1 + lam2 + (1 - lam1 - lam2)  # 0.0 表示 xq 的权重
        lam1 /= lam_sum
        lam2 /= lam_sum
        mixed_x = lam1 * xs1 + lam2 * xs2 + max(1 - lam1 - lam2) * xq  # Mixing operation.
        return mixed_x, ys1, ys2, yq, lam1, lam2

    # Forward pass through the network.
    def forward(self, x):
        return self.net(x)

    # Processes inputs through the first layer of the network and applies mixup, followed by the second layer.
    def forward_within(self, label_support1, inp_support1, inp_support2, label_support2, inp_query1, label_query1,
                       lam_mix, lam_mix2):
        hidden1_support = self.net[0](inp_support1)
        hidden1_query = self.net[0](inp_query1)
        hidden2_support = self.net[0](inp_support2)

        hidden1_query, reweighted_query1, reweighted_support1, reweighted_support2, \
        lam1, lam2 = self.mixup_data(hidden1_support, label_support1, hidden1_query, label_query1,
                                     hidden2_support, label_support2, lam_mix, lam_mix2

                                     )
        hidden2_query = self.net[1](hidden1_query)
        return hidden2_query, reweighted_query1, reweighted_support1, reweighted_support2
    def forward_crossmix(self, x):
        return self.net[1](x)