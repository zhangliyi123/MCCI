import torch
import torch.nn as nn
import torch.nn.functional as F
from utils import euclidean_dist
from learner import FCNet
import numpy as np
from torch.distributions import Beta
class Protonet(nn.Module):
    def __init__(self, args):
        super(Protonet, self).__init__()
        self.args = args
        self.learner = FCNet(args=args, x_dim=1024, hid_dim=500)
        if args.datasource == 'metabolism':
            self.dist1 = Beta(torch.FloatTensor([0.5]), torch.FloatTensor([0.5]))
            self.dist2 = Beta(torch.FloatTensor([0.5]), torch.FloatTensor([0.5]))
            self.dist3 = Beta(torch.FloatTensor([0.5]), torch.FloatTensor([0.5]))
            self.dist4 = Beta(torch.FloatTensor([0.5]), torch.FloatTensor([0.5]))
        elif args.datasource == 'NCI':
            self.dist1 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
            self.dist2 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
            self.dist3 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
            self.dist4 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))

    def forward(self, xs, ys, xq, yq):
        x = torch.cat([xs, xq], 0)
        z = self.learner(x)
        z_dim = z.size(-1)
        z_proto = z[:self.args.num_classes * self.args.update_batch_size].view(self.args.num_classes,self.args.update_batch_size, z_dim).mean(1)
        zq = z[self.args.num_classes * self.args.update_batch_size:]
        dists = euclidean_dist(zq, z_proto)
        log_p_y = F.log_softmax(-dists, dim=1)
        loss_val = []
        for i in range(self.args.num_classes * self.args.update_batch_size_eval):
            loss_val.append(-log_p_y[i, yq[i]])
        loss_val = torch.stack(loss_val).squeeze().mean()
        _, y_hat = log_p_y.max(1)
        acc_val = torch.eq(y_hat, yq).float().mean()
        return loss_val, acc_val

    def forward_within(self, xs1, ys1, xs2, ys2, xs3, ys3, xq1, yq1, xq2, yq2):
        lam_mix1 = self.dist1.sample().to("cuda")
        lam_mix2 = self.dist2.sample().to("cuda")
        lam_mix3 = self.dist3.sample().to("cuda")
        lam_mix4 = self.dist4.sample().to("cuda")
        z = self.learner(xs1)
        z_dim = z.size(-1)
        z_proto = z.view(self.args.num_classes, self.args.update_batch_size, z_dim).mean(1)
        zq, reweighted_yq, reweighted_ys, reweighted_yw, reweighted_yx, reweighted_yy, lam1, lam2, lam3, lam4 = \
            self.learner.forward_within( xs1, ys1, xs2, ys2, xs3, ys3, xq1, yq1, xq2, yq2, lam_mix1,lam_mix2, lam_mix3, lam_mix4)

        lam5 = max(1 - lam1 - lam2 -lam3 -lam4)
        lam1 = np.clip(lam1, 0, 1)
        lam2 = np.clip(lam2, 0, 1)
        lam3 = np.clip(lam2, 0, 1)
        lam4 = np.clip(lam2, 0, 1)
        lam_sum = lam1 + lam2 + lam3 + lam4 + (1 - lam1 - lam2 -lam3 -lam4) * 0.0  # 0.0 表示 xq 的权重
        lam1 /= lam_sum
        lam2 /= lam_sum
        lam3 /= lam_sum
        lam4 /= lam_sum
        dists = euclidean_dist(zq, z_proto)
        log_p_y = F.log_softmax(-dists, dim=1)
        loss_val = []

        for i in range(self.args.num_classes * self.args.update_batch_size_eval):
            loss_val.append(-log_p_y[i, reweighted_yq[i]]*lam3 -log_p_y[i, reweighted_yw[i]] * lam1
                            -log_p_y[i, reweighted_ys[i]] * lam2 -log_p_y[i, reweighted_yx[i]] * lam4  -log_p_y[i, reweighted_yy[i]] * lam5)
        loss_val = torch.stack(loss_val).squeeze().mean()
        zq_real = self.learner(xq1)
        dists_real = euclidean_dist(zq_real, z_proto)
        log_p_y_real = F.log_softmax(-dists_real, dim=1)
        _, y_hat = log_p_y_real.max(1)
        acc_val = torch.eq(y_hat, yq1).float().mean()
        return loss_val, acc_val

    def rand_bbox(self, size, lam):
        W = size[2]
        H = size[3]
        cut_rat = np.sqrt(1. - lam.cpu())
        cut_w = np.int(W * cut_rat)
        cut_h = np.int(H * cut_rat)
        # uniform
        cx = np.random.randint(W)
        cy = np.random.randint(H)
        bbx1 = np.clip(cx - cut_w // 2, 0, W)
        bby1 = np.clip(cy - cut_h // 2, 0, H)
        bbx2 = np.clip(cx + cut_w // 2, 0, W)
        bby2 = np.clip(cy + cut_h // 2, 0, H)
        return bbx1, bby1, bbx2, bby2



    def mixup_data(self, xq1, xq2, xs1, xs2, xs3, lam1, lam2, lam3, lam4):
        mixed_x = lam1 * xs1 + lam2 * xs2 + lam3 * xq1 + lam4 * xs3 + max(1 - lam1 - lam2 - lam3 -lam4) * xq2
        return mixed_x, lam1, lam2, lam3, lam4

    def forward_crossmix(self, x1s, y1s, x1q, y1q, x2s, y2s, x2q, y2q, x3s, y3s, x3q, y3q, x4s, y4s, x4q, y4q, x5s, y5s, x5q, y5q):
        lam_mix1 = self.dist1.sample().to("cuda")
        lam_mix2 = self.dist2.sample().to("cuda")
        lam_mix3 = self.dist3.sample().to("cuda")
        lam_mix4 = self.dist4.sample().to("cuda")
        task_2_shuffle_id1 = np.arange(self.args.num_classes)
        task_2_shuffle_id2 = np.arange(self.args.num_classes)
        task_2_shuffle_id3 = np.arange(self.args.num_classes)
        task_2_shuffle_id4 = np.arange(self.args.num_classes)
        np.random.shuffle(task_2_shuffle_id1)
        np.random.shuffle(task_2_shuffle_id2)
        np.random.shuffle(task_2_shuffle_id3)
        np.random.shuffle(task_2_shuffle_id4)
        task_2_shuffle_id_s1 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id1[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q1 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id1[idx] * self.args.update_batch_size_eval for
             idx in range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_s2 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id2[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q2 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id2[idx] * self.args.update_batch_size_eval
             for
             idx in range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_s3 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id3[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q3 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id3[idx] * self.args.update_batch_size_eval
             for
             idx in range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_s4 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id4[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q4 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id4[idx] * self.args.update_batch_size_eval
             for
             idx in range(self.args.num_classes)]).flatten()

        x2s = x2s[task_2_shuffle_id_s1]
        x2q = x2q[task_2_shuffle_id_q1]
        x3s = x3s[task_2_shuffle_id_s2]
        x3q = x3q[task_2_shuffle_id_q2]
        x4s = x4s[task_2_shuffle_id_s3]
        x4q = x4q[task_2_shuffle_id_q3]
        x5s = x5s[task_2_shuffle_id_s4]
        x5q = x5q[task_2_shuffle_id_q4]

        x_mix_s, _, _, _, _ = self.mixup_data(self.learner.net[0](x1s), self.learner.net[0](x2s), self.learner.net[0](x3s),
                                           self.learner.net[0](x4s), self.learner.net[0](x4s), lam_mix1, lam_mix2, lam_mix3, lam_mix4)

        x_mix_q, _, _, _, _ = self.mixup_data(self.learner.net[0](x1q), self.learner.net[0](x2q), self.learner.net[0](x3q),
                                           self.learner.net[0](x4q), self.learner.net[0](x5q), lam_mix1, lam_mix2, lam_mix3, lam_mix4)

        x = torch.cat([x_mix_s, x_mix_q], 0)

        z = self.learner.forward_crossmix(x)

        z_dim = z.size(-1)

        z_proto = z[:self.args.num_classes * self.args.update_batch_size].view(self.args.num_classes,
                                                                               self.args.update_batch_size, z_dim).mean(
            1)
        zq = z[self.args.num_classes * self.args.update_batch_size:]

        dists = euclidean_dist(zq, z_proto)

        log_p_y = F.log_softmax(-dists, dim=1)

        loss_val = []
        for i in range(self.args.num_classes * self.args.update_batch_size_eval):
            loss_val.append(-log_p_y[i, y1q[i]])

        loss_val = torch.stack(loss_val).squeeze().mean()

        _, y_hat = log_p_y.max(1)

        acc_val = torch.eq(y_hat, y1q).float().mean()

        return loss_val, acc_val