import torch
import torch.nn as nn
import torch.nn.functional as F
from utils import euclidean_dist
import numpy as np
from torch.distributions import Beta


class Protonet(nn.Module):
    def __init__(self, args, learner):
        super(Protonet, self).__init__()
        self.args = args
        self.learner = learner
        self.dist1 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
        self.dist2 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
        self.dist3 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
        self.dist4 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
        self.dist5 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
        self.dist6 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))

    def forward(self, xs, ys, xq, yq):
        x = torch.cat([xs, xq], 0)

        z = self.learner(x)

        z_dim = z.size(-1)

        z_proto = z[:self.args.num_classes * self.args.update_batch_size].view(self.args.num_classes,
                                                                               self.args.update_batch_size, z_dim).mean(
            1)
        zq = z[self.args.num_classes * self.args.update_batch_size:]

        dists = euclidean_dist(zq, z_proto)

        log_p_y = F.log_softmax(-dists, dim=1)

        loss_val = []
        for i in range(self.args.num_classes * self.args.update_batch_size_eval):
            loss_val.append(-log_p_y[i, yq[i]])

        loss_val = torch.stack(loss_val).squeeze().mean()

        _, y_hat = log_p_y.max(1)

        acc_val = torch.eq(y_hat, yq).float().mean()

        return loss_val, acc_val

    def rand_bbox(self, size, lam):
        W = size[2]
        H = size[3]
        cut_rat = np.sqrt(1. - lam.cpu())
        cut_w = np.int(W * cut_rat)
        cut_h = np.int(H * cut_rat)

        # uniform
        cx = np.random.randint(W)
        cy = np.random.randint(H)

        bbx1 = np.clip(cx - cut_w // 2, 0, W)
        bby1 = np.clip(cy - cut_h // 2, 0, H)
        bbx2 = np.clip(cx + cut_w // 2, 0, W)
        bby2 = np.clip(cy + cut_h // 2, 0, H)

        return bbx1, bby1, bbx2, bby2

    def mixup_data(self, xs1, xs2, xs3, xs4, xq1, xq2, xq3, lam1, lam2, lam3, lam4, lam5, lam6):

        mixed_x = xq3.clone()
        bbx1, bby1, bbx2, bby2 = self.rand_bbox(xq3.size(), lam1)
        bbx3, bby3, bbx4, bby4 = self.rand_bbox(xq3.size(), lam2)
        bbx5, bby5, bbx6, bby6 = self.rand_bbox(xq3.size(), lam3)
        bbx7, bby7, bbx8, bby8 = self.rand_bbox(xq3.size(), lam4)
        bbx9, bby9, bbx10, bby10 = self.rand_bbox(xq3.size(), lam5)
        bbx11, bby11, bbx12, bby12 = self.rand_bbox(xq3.size(), lam6)

        mixed_x[:, :, bbx1:bbx2, bby1:bby2] = xs1[:, :, bbx1:bbx2, bby1:bby2]
        mixed_x[:, :, bbx3:bbx4, bby3:bby4] = xs2[:, :, bbx3:bbx4, bby3:bby4]
        mixed_x[:, :, bbx5:bbx6, bby5:bby6] = xq1[:, :, bbx5:bbx6, bby5:bby6]
        mixed_x[:, :, bbx7:bbx8, bby7:bby8] = xq2[:, :, bbx7:bbx8, bby7:bby8]
        mixed_x[:, :, bbx9:bbx10, bby9:bby10] = xs3[:, :, bbx9:bbx10, bby9:bby10]
        mixed_x[:, :, bbx11:bbx12, bby11:bby12] = xs4[:, :, bbx11:bbx12, bby11:bby12]


        import random

        while lam2 + lam1 >= 1:
            lam2 = random.uniform(0, 1)
            lam3 = random.uniform(0, 1)
        while lam3 + lam2 + lam1 >= 1:
            lam3 = random.uniform(0, 1)
        while lam3 + lam2 + lam1 + lam4 >= 1:
            lam4 = random.uniform(0, 1)
        while lam3 + lam2 + lam1 + lam4 + lam5 >= 1:
            lam5 = random.uniform(0, 1)
        while lam3 + lam2 + lam1 + lam4 + lam5 + lam6 >= 1:
            lam6 = random.uniform(0, 1)

        return mixed_x, lam1, lam2, lam3, lam4, lam5, lam6

    def forward_crossmix(self, x1s, y1s, x1q, y1q, x2s, y2s, x2q, y2q, x3s, y3s, x3q, y3q, x4s, y4s, x4q, y4q, x5s, y5s,
                         x5q, y5q, x6s, y6s, x6q, y6q, x7s, y7s, x7q, y7q):
        lam_mix1 = self.dist1.sample().to("cuda")
        lam_mix2 = self.dist2.sample().to("cuda")
        lam_mix3 = self.dist3.sample().to("cuda")
        lam_mix4 = self.dist4.sample().to("cuda")
        lam_mix5 = self.dist5.sample().to("cuda")
        lam_mix6 = self.dist6.sample().to("cuda")

        task_2_shuffle_id1 = np.arange(self.args.num_classes)
        task_2_shuffle_id2 = np.arange(self.args.num_classes)
        task_2_shuffle_id3 = np.arange(self.args.num_classes)
        task_2_shuffle_id4 = np.arange(self.args.num_classes)
        task_2_shuffle_id5 = np.arange(self.args.num_classes)
        task_2_shuffle_id6 = np.arange(self.args.num_classes)
        task_2_shuffle_id7 = np.arange(self.args.num_classes)

        np.random.shuffle(task_2_shuffle_id1)
        np.random.shuffle(task_2_shuffle_id2)
        np.random.shuffle(task_2_shuffle_id3)
        np.random.shuffle(task_2_shuffle_id4)
        np.random.shuffle(task_2_shuffle_id5)
        np.random.shuffle(task_2_shuffle_id6)
        np.random.shuffle(task_2_shuffle_id7)

        task_2_shuffle_id_s1 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id1[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q1 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id1[idx] * self.args.update_batch_size_eval
             for
             idx in range(self.args.num_classes)]).flatten()

        task_2_shuffle_id_s2 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id2[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q2 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id2[idx] * self.args.update_batch_size_eval
             for
             idx in range(self.args.num_classes)]).flatten()

        task_2_shuffle_id_s3 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id3[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q3 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id3[idx] * self.args.update_batch_size_eval
             for
             idx in range(self.args.num_classes)]).flatten()

        task_2_shuffle_id_s4 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id4[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q4 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id4[idx] * self.args.update_batch_size_eval
             for
             idx in range(self.args.num_classes)]).flatten()

        task_2_shuffle_id_s5 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id5[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q5 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id5[idx] * self.args.update_batch_size_eval
             for
             idx in range(self.args.num_classes)]).flatten()

        task_2_shuffle_id_s6 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id6[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q6 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id6[idx] * self.args.update_batch_size_eval
             for
             idx in range(self.args.num_classes)]).flatten()

        task_2_shuffle_id_s7 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id7[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q7 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id7[idx] * self.args.update_batch_size_eval
             for
             idx in range(self.args.num_classes)]).flatten()

        x2s = x2s[task_2_shuffle_id_s1]
        x2q = x2q[task_2_shuffle_id_q1]
        x3s = x3s[task_2_shuffle_id_s2]
        x3q = x3q[task_2_shuffle_id_q2]
        x4s = x4s[task_2_shuffle_id_s3]
        x4q = x4q[task_2_shuffle_id_q3]
        x5s = x5s[task_2_shuffle_id_s4]
        x5q = x5q[task_2_shuffle_id_q4]
        x6s = x6s[task_2_shuffle_id_s6]
        x6q = x6q[task_2_shuffle_id_q6]
        x7s = x7s[task_2_shuffle_id_s7]
        x7q = x7q[task_2_shuffle_id_q7]

        x_mix_s, _, _, _, _, _, _ = self.mixup_data(x1s, x2s, x3s, x4s, x5s, x6s, x7s, lam_mix1, lam_mix2, lam_mix3, lam_mix4,
                                                 lam_mix5, lam_mix6)

        x_mix_q, _, _, _, _, _, _ = self.mixup_data(x1q, x2q, x3q, x4q, x5q, x6q, x7q, lam_mix1, lam_mix2, lam_mix3, lam_mix4,
                                                 lam_mix5, lam_mix6)

        x = torch.cat([x_mix_s, x_mix_q], 0)

        z = self.learner(x)

        z_dim = z.size(-1)

        z_proto = z[:self.args.num_classes * self.args.update_batch_size].view(self.args.num_classes,
                                                                               self.args.update_batch_size, z_dim).mean(
            1)
        zq = z[self.args.num_classes * self.args.update_batch_size:]

        dists = euclidean_dist(zq, z_proto)

        log_p_y = F.log_softmax(-dists, dim=1)

        loss_val = []
        for i in range(self.args.num_classes * self.args.update_batch_size_eval):
            loss_val.append(-log_p_y[i, y1q[i]])

        loss_val = torch.stack(loss_val).squeeze().mean()

        _, y_hat = log_p_y.max(1)

        acc_val = torch.eq(y_hat, y1q).float().mean()

        return loss_val, acc_val