import torch
import torch.nn as nn
import torch.nn.functional as F
from utils import euclidean_dist  # Utility for calculating Euclidean distance
import numpy as np
from torch.distributions import Beta  # For sampling from the Beta distribution

# The Protonet class defines a prototypical network with mixup and crossmix functionality.
class Protonet(nn.Module):
    def __init__(self, args, learner):
        super(Protonet, self).__init__()
        self.args = args  # Stores configuration parameters passed to the network
        self.learner = learner  # The neural network model used for embedding inputs
        # Beta distributions for generating mixup coefficients
        self.dist1 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))
        self.dist2 = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))

    def forward(self, xs, ys, xq, yq):
        # Concatenates support and query images and passes them through the learner to get embeddings
        x = torch.cat([xs, xq], 0)
        z = self.learner(x)
        # Calculates prototypes as the mean of embeddings from the support set
        z_dim = z.size(-1)
        z_proto = z[:self.args.num_classes * self.args.update_batch_size].view(self.args.num_classes,
                                                                               self.args.update_batch_size, z_dim).mean(1)
        zq = z[self.args.num_classes * self.args.update_batch_size:]
        # Calculates distances between query embeddings and prototypes, then computes loss and accuracy
        dists = euclidean_dist(zq, z_proto)
        log_p_y = F.log_softmax(-dists, dim=1)
        loss_val = [-log_p_y[i, yq[i]] for i in range(self.args.num_classes * self.args.update_batch_size_eval)]
        loss_val = torch.stack(loss_val).squeeze().mean()
        _, y_hat = log_p_y.max(1)
        acc_val = torch.eq(y_hat, yq).float().mean()
        return loss_val, acc_val

    def rand_bbox(self, size, lam):
        # Generates a random bounding box within the image, used for mixup regions
        W = size[2]
        H = size[3]
        cut_rat = np.sqrt(1. - lam.cpu())  # Determines the size of the box based on lambda
        cut_w = np.int(W * cut_rat)  # Box width
        cut_h = np.int(H * cut_rat)  # Box height
        cx = np.random.randint(W)  # Center x-coordinate
        cy = np.random.randint(H)  # Center y-coordinate
        # Calculates bounding box corners, ensuring they are within image dimensions
        bbx1 = np.clip(cx - cut_w // 2, 0, W)
        bby1 = np.clip(cy - cut_h // 2, 0, H)
        bbx2 = np.clip(cx + cut_w // 2, 0, W)
        bby2 = np.clip(cy + cut_h // 2, 0, H)
        return bbx1, bby1, bbx2, bby2

    def mixup_data(self, xs1, xs2, xq1, lam1, lam2):
        # Applies mixup by overlaying patches from xs1 and xs2 onto xq1 based on the mixup coefficients lam1 and lam2
        mixed_x = xq1.clone()
        bbx1, bby1, bbx2, bby2 = self.rand_bbox(xq1.size(), lam1)
        bbx3, bby3, bbx4, bby4 = self.rand_bbox(xq1.size(), lam2)
        mixed_x[:, :, bbx1:bbx2, bby1:bby2] = xs1[:, :, bbx1:bbx2, bby1:bby2]
        mixed_x[:, :, bbx3:bbx4, bby3:bby4] = xs2[:, :, bbx3:bbx4, bby3:bby4]
        # Ensures that the combined lambda values do not exceed 1
        while lam2 + lam1 >= 1:
            lam2 = np.random.uniform(0, 1)
        return mixed_x, lam1, lam2

    def forward_crossmix(self, x1s, y1s, x1q, y1q, x2s, y2s, x2q, y2q, x3s, y3s,x3q, y3q):
        # Sample mixup coefficients from Beta distributions
        lam_mix1 = self.dist1.sample().to("cuda")
        lam_mix2 = self.dist2.sample().to("cuda")
        # Shuffle class indices to ensure diversity in mixup combinations
        task_2_shuffle_id1 = np.arange(self.args.num_classes)
        task_2_shuffle_id2 = np.arange(self.args.num_classes)
        np.random.shuffle(task_2_shuffle_id1)
        np.random.shuffle(task_2_shuffle_id2)

        # Generate shuffled indices for support and query sets based on the shuffled class indices
        task_2_shuffle_id_s1 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id1[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q1 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id1[idx] * self.args.update_batch_size_eval
             for idx in range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_s2 = np.array(
            [np.arange(self.args.update_batch_size) + task_2_shuffle_id2[idx] * self.args.update_batch_size for idx in
             range(self.args.num_classes)]).flatten()
        task_2_shuffle_id_q2 = np.array(
            [np.arange(self.args.update_batch_size_eval) + task_2_shuffle_id2[idx] * self.args.update_batch_size_eval
             for idx in range(self.args.num_classes)]).flatten()

        # Apply the mixup augmentation to the support and query sets by overlaying patches from one set onto the others
        x2s = x2s[task_2_shuffle_id_s1]
        x2q = x2q[task_2_shuffle_id_q1]
        x3s = x3s[task_2_shuffle_id_s2]
        x3q = x3q[task_2_shuffle_id_q2]

        # Perform mixup augmentation on the sets
        x_mix_s, _, _ = self.mixup_data(x1s, x2s, x3s, lam_mix1, lam_mix2)
        x_mix_q, _, _ = self.mixup_data(x1q, x2q, x3q, lam_mix1, lam_mix2)

        # Concatenate the mixed support and query sets and process them through the learner model to get embeddings
        x = torch.cat([x_mix_s, x_mix_q], 0)
        z = self.learner(x)

        # Compute class prototypes as the mean of the embeddings from the mixed support set
        z_dim = z.size(-1)
        z_proto = z[:self.args.num_classes * self.args.update_batch_size].view(self.args.num_classes,
                                                                               self.args.update_batch_size, z_dim).mean(
            1)

        # Separate the query set embeddings
        zq = z[self.args.num_classes * self.args.update_batch_size:]

        # Calculate the distances from the query set embeddings to the class prototypes
        dists = euclidean_dist(zq, z_proto)

        # Compute the log softmax of the negative distances as predicted log probabilities
        log_p_y = F.log_softmax(-dists, dim=1)

        # Calculate the loss by accumulating the negative log probabilities of the correct classes
        loss_val = [-log_p_y[i, y1q[i]] for i in range(self.args.num_classes * self.args.update_batch_size_eval)]
        loss_val = torch.stack(loss_val).squeeze().mean()

        # Determine the predicted classes based on the highest log probability and calculate the accuracy
        _, y_hat = log_p_y.max(1)
        acc_val = torch.eq(y_hat, y1q).float().mean()

        return loss_val, acc_val

