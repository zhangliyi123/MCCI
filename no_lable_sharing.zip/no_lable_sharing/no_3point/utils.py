import torch

def euclidean_dist(x, y):
    # Calculates the Euclidean distance between two sets of vectors.
    # x: Tensor of shape N x D, where N is the number of samples in set x and D is the dimensionality of the samples.
    # y: Tensor of shape M x D, where M is the number of samples in set y and D is the dimensionality of the samples.
    n = x.size(0)  # Number of samples in set x
    m = y.size(0)  # Number of samples in set y
    d = x.size(1)  # Dimensionality of the samples
    assert d == y.size(1)  # Ensures both sets have the same dimensionality
    # Expands each tensor to make their shapes compatible for subtraction, resulting in a tensor of shape N x M x D.
    x = x.unsqueeze(1).expand(n, m, d)
    y = y.unsqueeze(0).expand(n, m, d)
    # Calculates the squared Euclidean distance and sums over the dimensionality, resulting in a tensor of shape N x M.
    return torch.pow(x - y, 2).sum(2)

def accuracy(output, target, topk=(1,)):
    # Computes the accuracy over the k top predictions for the specified values of k.
    # output: Model predictions, a tensor of shape (batch_size x num_classes).
    # target: Ground truth labels, a tensor of shape (batch_size).
    # topk: A tuple of integer values specifying the top-k accuracies to compute.
    maxk = max(topk)  # The maximum value of k
    batch_size = target.size(0)
    # Retrieves the indices of the topk predictions and transposes the result.
    _, pred = output.topk(maxk, 1, True, True)
    pred = pred.t()
    # Compares the predicted and true labels, expanding the target tensor for comparison.
    correct = pred.eq(target.view(1, -1).expand_as(pred))
    res = []
    for k in topk:
        # Counts the correct predictions in the top-k and computes the percentage.
        correct_k = correct[:k].view(-1).float().sum(0)
        res.append(correct_k.mul_(100.0 / batch_size))
    return res
