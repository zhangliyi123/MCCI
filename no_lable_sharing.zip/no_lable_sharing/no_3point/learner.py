import torch
import torch.nn as nn
from torch.distributions import Beta

# A module that flattens the input tensor into a 2D tensor where the first dimension is the batch size.
class Flatten(nn.Module):
    def __init__(self):
        super(Flatten, self).__init__()

    def forward(self, x):
        # x.view changes the shape of x to (batch_size, -1), -1 means inferring the size from other dimensions
        return x.view(x.size(0), -1)

# A function to create a 3x3 convolutional layer with specified input/output planes and stride.
def conv3x3(in_planes, out_planes, stride=1):
    # Returns a 2D convolution layer with 3x3 kernel, specified stride and padding, and no bias term.
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=1, bias=False)

# Defines a standard convolutional neural network module.
class Conv_Standard(nn.Module):
    def __init__(self, args, x_dim, hid_dim, z_dim):
        super(Conv_Standard, self).__init__()
        self.args = args  # Stores the arguments provided to the model, potentially for configuration.
        # Defines the network as a sequence of convolutional blocks followed by a Flatten layer.
        self.net = nn.Sequential(
            self.conv_block(x_dim, hid_dim),  # First convolutional block.
            self.conv_block(hid_dim, hid_dim),  # Second convolutional block.
            self.conv_block(hid_dim, hid_dim),  # Third convolutional block.
            self.conv_block(hid_dim, z_dim),  # Fourth convolutional block, outputting z_dim channels.
            Flatten()  # Flatten the output for further processing or a fully connected layer.
        )
        self.dist = Beta(torch.FloatTensor([2]), torch.FloatTensor([2]))  # Beta distribution for sampling, possibly used for augmentation or regularization techniques.
        self.hid_dim = hid_dim  # Stores the hidden dimension size, potentially used in the network configuration.

    # Defines a convolutional block used in constructing the network.
    def conv_block(self, in_channels, out_channels):
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1),  # 3x3 convolution with padding to keep the size.
            nn.BatchNorm2d(out_channels),  # Batch normalization for stabilization.
            nn.ReLU(),  # ReLU activation function.
            nn.MaxPool2d(2)  # Max pooling with a 2x2 window to reduce the dimensions.
        )

    # Forward pass of the model that applies the defined sequence of operations to the input.
    def forward(self, x):
        return self.net(x)
